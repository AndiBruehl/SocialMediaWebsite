import Home from "./Home";
import Profile from "./Profile";

const pages = {
  Home,
  Profile,
};

export default pages;
