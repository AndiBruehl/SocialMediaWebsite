const Logo = () => {
  return (
    <a href="/">
      <img
        src="/logo.png"
        alt="velvet-vibe-logo"
        style={{ height: "60px", width: "auto" }}
      />
    </a>
  );
};

export default Logo;
